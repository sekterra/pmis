import '../tailwind.css';
